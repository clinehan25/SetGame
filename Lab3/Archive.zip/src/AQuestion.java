abstract class AQuestion implements Question {
  String question;
  String answer;

  public AQuestion(String question) {
    if ((question.length() == 0) || (question.charAt(question.length() - 1) != '?')) {
      throw new IllegalArgumentException("Invalid question text");
    }
    this.question = question;
    this.answer = "";
  }
}
